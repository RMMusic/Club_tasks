Font-Medical-Icons
==================

#### **72 ICONS (X2)** specialized in the Clinical & Medical world FREE and easy to use!
---
#### **Important!** Before use, **[please read the terms and conditions](http://www.hablamosjuntos.org/signage/symbols/faq.asp#2)** set by **[Hablamos Juntos](http://www.hablamosjuntos.org/)** who designed these icons package.

This package is a digital adaptation for use on the web media.

Exemple : **[http://samcome.github.io/webfont-medical-icons](http://samcome.github.io/webfont-medical-icons)**

###### includes:
SVGs, PNGs (64x64), Webfont (.eot, .ttf, .woff, .svg)

---
#### Using Icon Fonts into your project
---
1. Copy the fonts folder
`packages/webfont-medical-icons/fonts`

2. Copy the css file
`packages/webfont-medical-icons/wfmi-style.css`

3. In the head html, reference the location to the css file
`<link rel="stylesheet" href="../css/wfmi-style.css">`

4. Add classes to your elements
`<span class="icon-neurology" aria-hidden="true"></span>`

#### DONE! 
